// Chromebience — popup controller
import { SOUND_ICONS } from './icons.js';

const $ = (sel) => document.querySelector(sel);

const SOUNDS = [
  { id:'rain',          name:'Rain' },
  { id:'thunderstorm',  name:'Thunder' },
  { id:'ocean-waves',   name:'Ocean' },
  { id:'river',         name:'River' },
  { id:'wind',          name:'Wind' },
  { id:'fireplace',     name:'Fireplace' },
  { id:'birds',         name:'Birds' },
  { id:'crickets',      name:'Crickets' },
  { id:'frogs',         name:'Frogs' },
  { id:'white-noise',   name:'White noise' },
  { id:'pink-noise',    name:'Pink noise' },
  { id:'brown-noise',   name:'Brown noise' },
];

const PRESETS = [
  { id:'sleep',         emoji:'🌙', name:'Sleep' },
  { id:'deep-focus',    emoji:'🎯', name:'Deep focus' },
  { id:'reading',       emoji:'📖', name:'Reading' },
  { id:'meditation',    emoji:'🧘', name:'Meditation' },
  { id:'cozy-cabin',    emoji:'🪵', name:'Cozy cabin' },
  { id:'nature',        emoji:'🌿', name:'Nature escape' },
  { id:'ocean-calm',    emoji:'🌊', name:'Ocean calm' },
  { id:'cafe-focus',    emoji:'☕', name:'Café focus' },
  { id:'creative',      emoji:'✨', name:'Creative' },
  { id:'night',         emoji:'🌧️', name:'Night' },
  { id:'summer-night',  emoji:'🦗', name:'Summer night' },
  { id:'forest-camp',   emoji:'🏕️', name:'Forest camp' },
];

// Tints applied to the UI when a preset is active.
const PRESET_TINTS = {
  'sleep':        { a:'#7a8fff', b:'#b8a4ff', night:true },
  'night':        { a:'#5a6eb8', b:'#9b88e6', night:true },
  'summer-night': { a:'#6b7fc8', b:'#b8a4ff', night:true },
  'forest-camp':  { a:'#d39a6c', b:'#8fb87a', night:true },
  'nature':       { a:'#8fd6c8', b:'#a8d49a' },
  'ocean-calm':   { a:'#7fc8e6', b:'#8fd6c8' },
  'cozy-cabin':   { a:'#ffb088', b:'#ffc6b8' },
  'deep-focus':   { a:'#b8a4ff', b:'#8fa4ff' },
  'reading':      { a:'#e6c08a', b:'#d4a87a' },
  'meditation':   { a:'#b8a4ff', b:'#8fd6c8' },
  'cafe-focus':   { a:'#d4a87a', b:'#b8a4ff' },
  'creative':     { a:'#ffc6b8', b:'#b8a4ff' },
};

const QUOTES = [
  'Breathe in. Begin again.',
  'Stillness is also progress.',
  'A calm mind builds anything.',
  'Soft focus, sharp results.',
  'Let the noise outside settle.',
  'Slow is smooth. Smooth is fast.',
  'Listen — and the day arranges itself.',
  'Make space for what matters.',
];

const send = (msg) => new Promise(res => chrome.runtime.sendMessage(msg, res));

let state = null;
let playerExpanded = false;
let stateRefreshTimer = null;

async function init() {
  $('#quote').textContent = QUOTES[Math.floor(Math.random() * QUOTES.length)];
  state = await send({ target:'background', type:'get-state' });
  applyTheme(state.theme);
  renderNowPlayer();

  if (!state.onboarded) {
    $('#onboarding').classList.remove('hidden');
    $('#start-cta').addEventListener('click', async () => {
      await send({ target:'background', type:'set-onboarded' });
      $('#onboarding').classList.add('hidden');
      $('#app').classList.remove('hidden');
    });
  } else {
    $('#app').classList.remove('hidden');
  }

  renderPresets();
  renderSounds();
  renderFavorites();
  renderMaster();
  renderTimer();
  applyPresetTint(state.activePreset);
  wireGlobalControls();
}

function applyTheme(theme) {
  const dark = theme === 'dark' ||
    (theme === 'auto' && window.matchMedia('(prefers-color-scheme: dark)').matches);
  document.documentElement.classList.toggle('theme-dark', dark);
}

function applyPresetTint(id) {
  const root = document.documentElement;
  const tint = id && PRESET_TINTS[id];
  if (tint) {
    root.style.setProperty('--accent', tint.a);
    root.style.setProperty('--accent-2', tint.b);
  } else {
    root.style.removeProperty('--accent');
    root.style.removeProperty('--accent-2');
  }
  document.body.classList.toggle('night-mode', !!(tint && tint.night));
}

function renderMaster() {
  $('#master-vol').value = Math.round(state.master * 100);
  const anyPlaying = Object.values(state.sounds).some(s => s.playing) && !state.muted;
  $('#viz').classList.toggle('active', anyPlaying);
  $('#now-playing-fab').classList.toggle('active', anyPlaying);
  $('#play-icon').innerHTML = anyPlaying
    ? '<path d="M6 5h4v14H6zm8 0h4v14h-4z"/>'
    : '<path d="M8 5v14l11-7z"/>';
}

function renderNowPlayer() {
  $('#now-player').classList.toggle('hidden', !playerExpanded);
  $('#now-playing-fab').classList.toggle('expanded', playerExpanded);
}

function renderPresets() {
  const c = $('#presets'); c.innerHTML = '';
  for (const p of PRESETS) {
    const b = document.createElement('button');
    b.className = 'preset' + (state.activePreset === p.id ? ' active' : '');
    b.innerHTML = `<span class="emoji">${p.emoji}</span><span>${p.name}</span>`;
    b.addEventListener('click', async () => {
      state = await send({ target:'background', type:'apply-preset', id: p.id });
      renderAll();
    });
    c.appendChild(b);
  }
}

function renderSounds() {
  const c = $('#sounds'); c.innerHTML = '';
  for (const s of SOUNDS) {
    const data = state.sounds[s.id];
    const card = document.createElement('div');
    card.className = 'sound' + (data.playing ? ' active' : '');
    if (data.missing) card.classList.add('missing');
    card.innerHTML = `
      <div class="sound-head">
        <div class="icon">${SOUND_ICONS[s.id] || SOUND_ICONS.default}</div>
        <div class="name">${s.name}${data.missing ? '<small>Missing file</small>' : ''}</div>
        <button class="toggle" title="${data.missing ? 'Retry sound file' : 'Toggle'}">
          ${data.playing
            ? '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M6 5h4v14H6zm8 0h4v14h-4z"/></svg>'
            : '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M8 5v14l11-7z"/></svg>'}
        </button>
      </div>
      <input type="range" class="slider" min="0" max="100" value="${Math.round(data.volume*100)}"/>
    `;
    card.querySelector('.toggle').addEventListener('click', async () => {
      state = await send({ target:'background', type:'toggle-sound', id: s.id });
      renderAll();
    });
    card.querySelector('.slider').addEventListener('input', async (e) => {
      const v = +e.target.value / 100;
      state = await send({ target:'background', type:'set-volume', id: s.id, volume: v });
      renderMaster();
    });
    c.appendChild(card);
  }
}

function renderFavorites() {
  const sec = $('#fav-section'); const c = $('#favorites');
  c.innerHTML = '';
  if (!state.favorites || state.favorites.length === 0) { sec.hidden = true; return; }
  sec.hidden = false;
  for (const f of state.favorites) {
    const row = document.createElement('div'); row.className = 'fav';
    row.innerHTML = `<span class="name">${escapeHtml(f.name)}</span>
      <button data-play title="Play">▶</button>
      <button data-del title="Delete">✕</button>`;
    row.querySelector('[data-play]').addEventListener('click', async () => {
      state = await send({ target:'background', type:'apply-mix', mix: f.mix });
      renderAll();
    });
    row.querySelector('[data-del]').addEventListener('click', async () => {
      state = await send({ target:'background', type:'delete-favorite', id: f.id });
      renderFavorites();
    });
    c.appendChild(row);
  }
}

function renderTimer() {
  const el = $('#timer-state');
  document.querySelectorAll('[data-min]').forEach(b => b.classList.remove('active'));
  if (state.timer && state.timer.endsAt > Date.now()) {
    const mins = Math.ceil((state.timer.endsAt - Date.now()) / 60000);
    el.textContent = `Fades in ~${mins}m`;
    $('#timer-cancel').hidden = false;
  } else {
    el.textContent = '';
    $('#timer-cancel').hidden = true;
  }
}

function renderAll() {
  renderPresets(); renderSounds(); renderFavorites(); renderMaster(); renderTimer();
  renderNowPlayer();
  applyPresetTint(state.activePreset);
}

function wireGlobalControls() {
  $('#master-vol').addEventListener('input', async (e) => {
    state = await send({ target:'background', type:'set-master', volume: +e.target.value/100 });
    renderMaster();
  });
  $('#mute-btn').addEventListener('click', async () => {
    state = await send({ target:'background', type:'toggle-mute' });
    renderMaster();
  });
  $('#play-all').addEventListener('click', async () => {
    const anyPlaying = Object.values(state.sounds).some(s => s.playing);
    if (anyPlaying) {
      state = await send({ target:'background', type:'stop-all' });
    } else if (state.activePreset) {
      state = await send({ target:'background', type:'apply-preset', id: state.activePreset });
    } else {
      state = await send({ target:'background', type:'apply-preset', id: 'deep-focus' });
    }
    renderAll();
  });
  $('#stop-all').addEventListener('click', async () => {
    state = await send({ target:'background', type:'stop-all' });
    renderAll();
  });
  $('#theme-btn').addEventListener('click', async () => {
    const order = ['light','dark','auto'];
    const next = order[(order.indexOf(state.theme) + 1) % order.length];
    state = await send({ target:'background', type:'set-theme', theme: next });
    applyTheme(next);
    $('#theme-btn').setAttribute('title', `Theme: ${next}`);
  });
  const togglePlayer = () => {
    playerExpanded = !playerExpanded;
    renderNowPlayer();
  };
  $('#mini-btn').addEventListener('click', togglePlayer);
  $('#now-playing-fab').addEventListener('click', togglePlayer);
  $('#save-fav').addEventListener('click', async () => {
    const active = Object.entries(state.sounds).filter(([,v]) => v.playing);
    if (active.length === 0) return;
    const name = prompt('Name this mix', 'My mix');
    if (!name) return;
    const mix = Object.fromEntries(active.map(([k,v]) => [k, v.volume]));
    state = await send({ target:'background', type:'save-favorite', name, mix });
    renderFavorites();
  });

  // Timer chips
  document.querySelectorAll('[data-min]').forEach(b => {
    b.addEventListener('click', async () => {
      const min = +b.dataset.min;
      state = await send({ target:'background', type:'start-timer', minutes: min });
      renderTimer();
    });
  });
  $('#timer-custom').addEventListener('change', async (e) => {
    const min = +e.target.value;
    if (!min || min < 1) return;
    state = await send({ target:'background', type:'start-timer', minutes: min });
    e.target.value = '';
    renderTimer();
  });
  $('#timer-cancel').addEventListener('click', async () => {
    state = await send({ target:'background', type:'cancel-timer' });
    renderTimer();
  });

  // refresh state when storage changes (other contexts / commands)
  chrome.storage.onChanged.addListener(async (changes, area) => {
    if (area === 'local' && changes.state) {
      state = changes.state.newValue;
      renderAll();
    }
  });

  document.addEventListener('visibilitychange', async () => {
    if (!document.hidden) {
      state = await send({ target:'background', type:'get-state' });
      renderAll();
    }
  });

  stateRefreshTimer = setInterval(async () => {
    if (document.hidden) return;
    state = await send({ target:'background', type:'get-state' });
    renderAll();
  }, 2500);

  window.addEventListener('unload', () => {
    if (stateRefreshTimer) clearInterval(stateRefreshTimer);
  });

  window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', () => {
    if (state.theme === 'auto') applyTheme('auto');
  });
}

function escapeHtml(s){ return String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }

init();
