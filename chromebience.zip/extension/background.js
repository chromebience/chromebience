// Chromebience — Background service worker
// Manages the offscreen audio document, state persistence, commands & timers.

const OFFSCREEN_PATH = 'offscreen.html';

const SOUNDS = [
  'birds', 'brown-noise', 'crickets', 'fireplace', 'frogs', 'ocean-waves',
  'pink-noise', 'rain', 'river', 'thunderstorm', 'white-noise', 'wind'
];

const PRESETS = {
  'sleep':         { rain:0.6, thunderstorm:0.3, crickets:0.35 },
  'deep-focus':    { 'brown-noise':0.6, river:0.35 },
  'reading':       { 'brown-noise':0.5 },
  'meditation':    { river:0.4, wind:0.3, crickets:0.3 },
  'cozy-cabin':    { fireplace:0.6, rain:0.5 },
  'nature':        { birds:0.45, frogs:0.35, river:0.45, crickets:0.3 },
  'ocean-calm':    { 'ocean-waves':0.7, wind:0.3 },
  'cafe-focus':    { 'pink-noise':0.35, 'brown-noise':0.25, river:0.2 },
  'creative':      { 'pink-noise':0.5, wind:0.35 },
  'night':         { crickets:0.5, thunderstorm:0.3, fireplace:0.4 },
  'summer-night':  { crickets:0.6, wind:0.3, frogs:0.35 },
  'forest-camp':   { crickets:0.4, fireplace:0.55, wind:0.3 }
};

const DEFAULT_STATE = {
  master: 0.8,
  muted: false,
  sounds: Object.fromEntries(SOUNDS.map(s => [s, { playing:false, volume:0.5, missing:false }])),
  theme: 'auto',          // 'light' | 'dark' | 'auto'
  activePreset: null,
  favorites: [],          // [{ id, name, mix:{...} }]
  onboarded: false,
  timer: null             // { endsAt:number, fadeMs:number }
};

async function getState() {
  const { state } = await chrome.storage.local.get('state');
  const storedSounds = (state && state.sounds) || {};
  const sounds = Object.fromEntries(SOUNDS.map(id => [
    id,
    { ...DEFAULT_STATE.sounds[id], ...(storedSounds[id] || {}) }
  ]));
  return { ...DEFAULT_STATE, ...(state || {}), sounds };
}
async function setState(patch) {
  const cur = await getState();
  const next = { ...cur, ...patch };
  await chrome.storage.local.set({ state: next });
  return next;
}

// Offscreen document lifecycle ------------------------------------------------
async function hasOffscreen() {
  if (!chrome.runtime.getContexts) return false;
  const ctx = await chrome.runtime.getContexts({ contextTypes: ['OFFSCREEN_DOCUMENT'] });
  return ctx.length > 0;
}
async function ensureOffscreen() {
  if (await hasOffscreen()) return;
  await chrome.offscreen.createDocument({
    url: OFFSCREEN_PATH,
    reasons: ['AUDIO_PLAYBACK'],
    justification: 'Continuous ambient sound playback while the user browses.'
  });
}

async function pushStateToOffscreen() {
  await ensureOffscreen();
  const state = await getState();
  await chrome.runtime.sendMessage({ target:'offscreen', type:'sync', state }).catch(() => {});
}

// Message routing -------------------------------------------------------------
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  (async () => {
    if (!msg || msg.target && msg.target !== 'background') return;
    switch (msg.type) {
      case 'get-state': {
        sendResponse(await getState()); return;
      }
      case 'toggle-sound': {
        const s = await getState();
        s.sounds[msg.id].playing = !s.sounds[msg.id].playing;
        if (s.sounds[msg.id].playing) s.sounds[msg.id].missing = false;
        s.activePreset = null;
        await chrome.storage.local.set({ state: s });
        await pushStateToOffscreen();
        sendResponse(s); return;
      }
      case 'set-volume': {
        const s = await getState();
        s.sounds[msg.id].volume = msg.volume;
        await chrome.storage.local.set({ state: s });
        if (s.sounds[msg.id].playing) {
          await ensureOffscreen();
          await chrome.runtime.sendMessage({ target:'offscreen', type:'set-sound-volume', id: msg.id, volume: msg.volume, ms: 120 }).catch(() => {});
        }
        sendResponse(s); return;
      }
      case 'set-master': {
        const s = await setState({ master: msg.volume });
        await ensureOffscreen();
        await chrome.runtime.sendMessage({ target:'offscreen', type:'set-master', volume: s.muted ? 0 : s.master, ms: 120 }).catch(() => {});
        sendResponse(s); return;
      }
      case 'toggle-mute': {
        const cur = await getState();
        const s = await setState({ muted: !cur.muted });
        await pushStateToOffscreen(); sendResponse(s); return;
      }
      case 'apply-preset': {
        const preset = PRESETS[msg.id];
        if (!preset) { sendResponse(null); return; }
        const s = await getState();
        for (const id of SOUNDS) {
          s.sounds[id].playing = !!preset[id];
          if (preset[id]) s.sounds[id].volume = preset[id];
          if (preset[id]) s.sounds[id].missing = false;
        }
        s.activePreset = msg.id;
        await chrome.storage.local.set({ state: s });
        await pushStateToOffscreen();
        sendResponse(s); return;
      }
      case 'apply-mix': {
        const s = await getState();
        for (const id of SOUNDS) {
          const v = msg.mix[id];
          s.sounds[id].playing = !!v;
          if (v) s.sounds[id].volume = v;
          if (v) s.sounds[id].missing = false;
        }
        s.activePreset = null;
        await chrome.storage.local.set({ state: s });
        await pushStateToOffscreen();
        sendResponse(s); return;
      }
      case 'stop-all': {
        const s = await getState();
        for (const id of SOUNDS) s.sounds[id].playing = false;
        s.activePreset = null;
        s.timer = null;
        await chrome.alarms.clear('chromebience-timer');
        await chrome.storage.local.set({ state: s });
        await ensureOffscreen();
        await chrome.runtime.sendMessage({ target:'offscreen', type:'stop-all', ms: 0 }).catch(() => {});
        sendResponse(s); return;
      }
      case 'sound-unavailable': {
        const s = await getState();
        if (s.sounds[msg.id]) {
          s.sounds[msg.id].playing = false;
          s.sounds[msg.id].missing = true;
          await chrome.storage.local.set({ state: s });
        }
        sendResponse({ ok:true }); return;
      }
      case 'sound-available': {
        const s = await getState();
        if (s.sounds[msg.id] && s.sounds[msg.id].missing) {
          s.sounds[msg.id].missing = false;
          await chrome.storage.local.set({ state: s });
        }
        sendResponse({ ok:true }); return;
      }
      case 'set-theme': {
        const s = await setState({ theme: msg.theme });
        sendResponse(s); return;
      }
      case 'set-onboarded': {
        const s = await setState({ onboarded: true });
        sendResponse(s); return;
      }
      case 'save-favorite': {
        const s = await getState();
        const fav = { id: crypto.randomUUID(), name: msg.name, mix: msg.mix };
        s.favorites = [...s.favorites, fav];
        await chrome.storage.local.set({ state: s });
        sendResponse(s); return;
      }
      case 'delete-favorite': {
        const s = await getState();
        s.favorites = s.favorites.filter(f => f.id !== msg.id);
        await chrome.storage.local.set({ state: s });
        sendResponse(s); return;
      }
      case 'start-timer': {
        const endsAt = Date.now() + msg.minutes * 60_000;
        const s = await setState({ timer: { endsAt, fadeMs: 8000 } });
        await chrome.alarms.create('chromebience-timer', { when: endsAt });
        sendResponse(s); return;
      }
      case 'cancel-timer': {
        await chrome.alarms.clear('chromebience-timer');
        const s = await setState({ timer: null });
        await pushStateToOffscreen();
        sendResponse(s); return;
      }
      case 'list-presets': {
        sendResponse(PRESETS); return;
      }
    }
  })();
  return true; // async
});

// Keyboard commands -----------------------------------------------------------
chrome.commands.onCommand.addListener(async (cmd) => {
  const s = await getState();
  if (cmd === 'toggle-play-all') {
    const anyPlaying = Object.values(s.sounds).some(x => x.playing);
    if (anyPlaying) {
      await chrome.runtime.sendMessage({ target:'background', type:'stop-all' }).catch(()=>{});
      return;
    } else if (s.activePreset) {
      // restart last preset
      const preset = PRESETS[s.activePreset];
      for (const id of SOUNDS) {
        s.sounds[id].playing = !!preset[id];
        if (preset[id]) s.sounds[id].volume = preset[id];
        if (preset[id]) s.sounds[id].missing = false;
      }
    } else {
      const preset = PRESETS['deep-focus'];
      for (const id of SOUNDS) {
        s.sounds[id].playing = !!preset[id];
        if (preset[id]) s.sounds[id].volume = preset[id];
        if (preset[id]) s.sounds[id].missing = false;
      }
      s.activePreset = 'deep-focus';
    }
    await chrome.storage.local.set({ state: s });
    await pushStateToOffscreen();
  } else if (cmd === 'mute-all') {
    await setState({ muted: !s.muted });
    await pushStateToOffscreen();
  } else if (cmd === 'next-preset') {
    const ids = Object.keys(PRESETS);
    const idx = s.activePreset ? ids.indexOf(s.activePreset) : -1;
    const nextId = ids[(idx + 1) % ids.length];
    const preset = PRESETS[nextId];
    for (const id of SOUNDS) {
      s.sounds[id].playing = !!preset[id];
      if (preset[id]) s.sounds[id].volume = preset[id];
      if (preset[id]) s.sounds[id].missing = false;
    }
    s.activePreset = nextId;
    await chrome.storage.local.set({ state: s });
    await pushStateToOffscreen();
  }
});

// Timer fade-out --------------------------------------------------------------
chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name !== 'chromebience-timer') return;
  await ensureOffscreen();
  await chrome.runtime.sendMessage({ target:'offscreen', type:'fade-out', ms: 8000 });
  setTimeout(async () => {
    const s = await getState();
    for (const id of SOUNDS) s.sounds[id].playing = false;
    s.timer = null;
    await chrome.storage.local.set({ state: s });
    await pushStateToOffscreen();
  }, 8200);
});

// Make sure offscreen exists once user has any active sounds.
chrome.runtime.onStartup.addListener(async () => {
  const s = await getState();
  if (Object.values(s.sounds).some(x => x.playing)) {
    await pushStateToOffscreen();
  }
});
chrome.runtime.onInstalled.addListener(async () => {
  await getState(); // initialize defaults
});
