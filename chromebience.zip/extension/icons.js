// Hand-drawn pastel line icons for each sound. Inherits currentColor.
const I = (path) => `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">${path}</svg>`;

export const SOUND_ICONS = {
  rain:           I('<path d="M7 14a4 4 0 0 1 .5-7.96A5.5 5.5 0 0 1 18 8a3.5 3.5 0 0 1-.5 6.95"/><path d="M9 17v2M12 17v3M15 17v2"/>'),
  thunderstorm:   I('<path d="M7 14a4 4 0 0 1 .5-7.96A5.5 5.5 0 0 1 18 8a3.5 3.5 0 0 1-.5 6.95"/><path d="M12 14l-2 4h3l-1.5 4"/>'),
  'ocean-waves':  I('<path d="M2 10c2 0 3-2 5-2s3 2 5 2 3-2 5-2 3 2 5 2"/><path d="M2 15c2 0 3-2 5-2s3 2 5 2 3-2 5-2 3 2 5 2"/><path d="M2 20c2 0 3-2 5-2s3 2 5 2 3-2 5-2 3 2 5 2"/>'),
  river:          I('<path d="M3 8c3 0 3-3 6-3s3 3 6 3 3-3 6-3"/><path d="M3 14c3 0 3-3 6-3s3 3 6 3 3-3 6-3"/><path d="M3 20c3 0 3-3 6-3s3 3 6 3 3-3 6-3"/>'),
  wind:           I('<path d="M3 8h11a3 3 0 1 0-3-3"/><path d="M3 14h15a3 3 0 1 1-3 3"/><path d="M3 20h7"/>'),
  fireplace:      I('<path d="M12 21c4 0 6-3 6-6 0-3-3-4-3-7 0 2-2 2-2 4 0-3-3-4-3-7-1 4-4 5-4 10 0 3 2 6 6 6z"/>'),
  birds:          I('<path d="M3 11c2-3 4-3 6 0M9 11c2-3 4-3 6 0"/><path d="M2 17c4-2 9-1 13 1M14 17c2-1 5-1 8 0"/>'),
  frogs:          I('<circle cx="8" cy="10" r="2"/><circle cx="16" cy="10" r="2"/><path d="M5 14c1 3 4 5 7 5s6-2 7-5"/><path d="M4 14c-1 0-2-1-2-2M20 14c1 0 2-1 2-2"/>'),
  crickets:       I('<ellipse cx="12" cy="14" rx="4" ry="3"/><path d="M9 12l-3-2M15 12l3-2M8 14l-4 1M16 14l4 1M10 17l-2 3M14 17l2 3"/><circle cx="10.5" cy="13" r="0.5" fill="currentColor"/><circle cx="13.5" cy="13" r="0.5" fill="currentColor"/>'),
  'white-noise':  I('<path d="M3 12h2l2-7 3 14 3-11 2 8 2-5h4"/>'),
  'pink-noise':   I('<path d="M3 12h3l2-6 3 12 3-9 2 6 2-3h3"/>'),
  'brown-noise':  I('<path d="M3 12h3l2-5 2 10 3-8 2 5 2-2h4"/>'),
  default:        I('<circle cx="12" cy="12" r="4"/><path d="M12 4v2M12 18v2M4 12h2M18 12h2"/>'),
};
