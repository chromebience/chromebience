# Chromebience — Ambient Focus (Chrome Extension)

A premium Manifest V3 Chrome extension that mixes ambient sounds for focus,
sleep, study, meditation, and deep work. Audio keeps playing across tabs and
when the popup is closed, via a persistent **offscreen document**.

## 1. Add your sound files

Drop your HD MP3s into the `sounds/` folder, named exactly:

```
sounds/birds.mp3
sounds/brown-noise.mp3
sounds/crickets.mp3
sounds/fireplace.mp3
sounds/frogs.mp3
sounds/ocean-waves.mp3
sounds/pink-noise.mp3
sounds/rain.mp3
sounds/river.mp3
sounds/thunderstorm.mp3
sounds/white-noise.mp3
sounds/wind.mp3
```

Files should be seamlessly loopable for best results. `cricket.mp3` also works
as an alias for `crickets.mp3`.

## 2. Load the extension

1. Open `chrome://extensions`
2. Toggle **Developer mode** (top right)
3. Click **Load unpacked**
4. Select this folder

Works in Chrome, Edge, Brave, Arc, Opera, and any Chromium browser.

## 3. Keyboard shortcuts

| Action            | Shortcut       |
|-------------------|----------------|
| Play / pause all  | `Alt+Shift+P`  |
| Mute / unmute     | `Alt+Shift+M`  |
| Next preset       | `Alt+Shift+N`  |

Customize in `chrome://extensions/shortcuts`.

## Architecture

- **`manifest.json`** — MV3 manifest, permissions, commands
- **`background.js`** — Service worker. State, presets, timer, commands, message routing
- **`offscreen.html` / `offscreen.js`** — Persistent Web Audio host with gapless loops, per-sound gain nodes, shared master gain, and graceful missing-file fallbacks
- **`popup.html` / `popup.css` / `popup.js`** — Glassmorphic UI
- **`icons.js`** — Inline pastel line icons
- **`sounds/`** — Your MP3s (gitignored placeholder included)
- **`icons/`** — App icons (16/48/128)

State is persisted in `chrome.storage.local` and synced across popup ↔ background ↔ offscreen via `chrome.runtime` messaging.

## Roadmap (already scaffolded)

The state shape, message bus, and presets are designed so you can layer in:
freemium gating, premium sound packs, AI-generated soundscapes, accounts &
cloud sync, Pomodoro, analytics, streaks, mood-based recs, Spotify, dynamic
layering, seasonal packs, creator marketplace.
