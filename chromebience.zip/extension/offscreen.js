// Chromebience — Offscreen audio document
// Web Audio API gapless looping. Fade-in only on FIRST start, not on loop restart.

const SOUNDS = [
  'birds', 'brown-noise', 'crickets', 'fireplace', 'frogs', 'ocean-waves',
  'pink-noise', 'rain', 'river', 'thunderstorm', 'white-noise', 'wind'
];

// Sounds that benefit from subtle stereo widening (nature-y, ambient).
const WIDE = new Set(['birds', 'crickets', 'frogs', 'ocean-waves', 'river', 'rain', 'wind', 'thunderstorm', 'fireplace']);

const FADE_IN_MS  = 1200;
const FADE_OUT_MS = 700;

const FILE_ALIASES = {
  birds: ['birds.mp3'],
  'brown-noise': ['brown-noise.mp3', 'brownnoise.mp3'],
  crickets: ['cricket.mp3', 'crickets.mp3'],
  fireplace: ['fireplace.mp3', 'fire.mp3'],
  frogs: ['frogs.mp3', 'frog.mp3'],
  'ocean-waves': ['ocean-waves.mp3', 'ocean.mp3', 'waves.mp3'],
  'pink-noise': ['pink-noise.mp3', 'pinknoise.mp3'],
  rain: ['rain.mp3'],
  river: ['river.mp3', 'stream.mp3'],
  thunderstorm: ['thunderstorm.mp3', 'thunder.mp3'],
  'white-noise': ['white-noise.mp3', 'whitenoise.mp3'],
  wind: ['wind.mp3']
};

const SOUND_LABELS = Object.fromEntries(SOUNDS.map(id => [id, id.split('-').map(w => w[0].toUpperCase() + w.slice(1)).join(' ')]));

let ctx = null;
let masterGain = null;
const nodes = {}; // id -> { source, gain, panner, lfo, lfoGain, buffer, playing, targetVol }
const loading = {}; // id -> Promise<AudioBuffer>
const missing = new Set();
const warnedMissing = new Set();
const desiredPlaying = Object.fromEntries(SOUNDS.map(id => [id, false]));

function ensureCtx() {
  if (!ctx) ctx = new (self.AudioContext || self.webkitAudioContext)({ latencyHint: 'playback' });
  if (ctx.state === 'suspended') ctx.resume().catch(() => {});
  if (!masterGain) {
    masterGain = ctx.createGain();
    masterGain.gain.value = 0.8;
    masterGain.connect(ctx.destination);
  }
  return ctx;
}

function warnMissing(id) {
  if (warnedMissing.has(id)) return;
  warnedMissing.add(id);
  console.warn(`[Chromebience] ${SOUND_LABELS[id] || id} sound file missing`);
}

function notify(type, payload = {}) {
  chrome.runtime.sendMessage({ target: 'background', type, ...payload }).catch(() => {});
}

async function loadBuffer(id) {
  if (missing.has(id)) return null;
  if (loading[id]) return loading[id];
  loading[id] = (async () => {
    const files = FILE_ALIASES[id] || [`${id}.mp3`];
    for (const file of files) {
      try {
        const res = await fetch(chrome.runtime.getURL(`sounds/${file}`), { cache: 'force-cache' });
        if (!res.ok) continue;
        const arr = await res.arrayBuffer();
        const buffer = await ensureCtx().decodeAudioData(arr);
        missing.delete(id);
        notify('sound-available', { id });
        return buffer;
      } catch (_err) {
        // Missing packaged resources can reject fetch in extension pages. Keep this quiet;
        // a single clean warning is emitted below if every alias fails.
      }
    }
    missing.add(id);
    delete loading[id];
    warnMissing(id);
    notify('sound-unavailable', { id });
    return null;
  })().catch(err => {
    console.warn(`[Chromebience] Could not decode ${SOUND_LABELS[id] || id} sound file`);
    delete loading[id];
    return null;
  });
  return loading[id];
}

function rampTo(param, value, ms) {
  const c = ensureCtx();
  const now = c.currentTime;
  // Smooth ramps prevent clicks/pops during realtime control changes.
  param.cancelScheduledValues(now);
  param.setValueAtTime(param.value, now);
  param.linearRampToValueAtTime(value, now + ms / 1000);
}

function setMasterVolume(value, ms = 180) {
  ensureCtx();
  rampTo(masterGain.gain, Math.max(0, Math.min(1, value)), ms);
}

async function startSound(id, vol) {
  const c = ensureCtx();
  desiredPlaying[id] = true;
  let n = nodes[id];

  // Already playing → just update target volume smoothly, no fade restart.
  if (n && n.playing) {
    n.targetVol = vol;
    rampTo(n.gain.gain, vol, 250);
    return;
  }

  const buffer = await loadBuffer(id);
  if (!desiredPlaying[id]) return;
  if (!buffer) return;

  // Build the graph: source -> [panner] -> individual gain -> master gain -> destination
  const source = c.createBufferSource();
  source.buffer = buffer;
  source.loop = true; // Gapless — Web Audio loops the decoded buffer seamlessly.

  const gain = c.createGain();
  gain.gain.value = 0; // fade in from silence

  let panner = null, lfo = null, lfoGain = null;
  if (WIDE.has(id) && c.createStereoPanner) {
    panner = c.createStereoPanner();
    // Slow LFO drifts pan between -0.25 .. +0.25 for subtle stereo widening.
    lfo = c.createOscillator();
    lfo.frequency.value = 0.03 + Math.random() * 0.04; // ~25–40s period
    lfoGain = c.createGain();
    lfoGain.gain.value = 0.25;
    lfo.connect(lfoGain).connect(panner.pan);
    lfo.start();
    source.connect(panner).connect(gain).connect(masterGain);
  } else {
    source.connect(gain).connect(masterGain);
  }

  source.start(0);
  // Fade in only here — happens once, at first start.
  rampTo(gain.gain, vol, FADE_IN_MS);

  nodes[id] = { source, gain, panner, lfo, lfoGain, buffer, playing: true, targetVol: vol };
}

function stopSound(id, ms = FADE_OUT_MS) {
  desiredPlaying[id] = false;
  const n = nodes[id];
  if (!n || !n.playing) return;
  n.playing = false;
  const c = ensureCtx();
  if (ms <= 0) {
    n.gain.gain.cancelScheduledValues(c.currentTime);
    n.gain.gain.setValueAtTime(0, c.currentTime);
    try { n.source.stop(c.currentTime + 0.01); } catch {}
    try { n.lfo && n.lfo.stop(c.currentTime + 0.01); } catch {}
    delete nodes[id];
    return;
  }
  rampTo(n.gain.gain, 0, ms);
  setTimeout(() => {
    try { n.source.stop(); } catch {}
    try { n.lfo && n.lfo.stop(); } catch {}
    delete nodes[id];
  }, ms + 80);
}

function stopAll(ms = 0) {
  ensureCtx();
  for (const id of Object.keys(nodes)) stopSound(id, ms);
}

function setVolume(id, vol, ms = 200) {
  const n = nodes[id];
  if (!n) return;
  n.targetVol = vol;
  rampTo(n.gain.gain, vol, ms);
}

async function sync(state) {
  ensureCtx();
  setMasterVolume(state.muted ? 0 : (state.master ?? 0.8));
  for (const id of SOUNDS) {
    const s = state.sounds[id];
    if (!s) continue;
    desiredPlaying[id] = !!s.playing;
    if (s.playing && s.missing === false && missing.has(id)) missing.delete(id);
    const target = Math.max(0, Math.min(1, s.volume));
    if (s.playing) {
      const n = nodes[id];
      if (!n || !n.playing) await startSound(id, target);
      else setVolume(id, target);
    } else {
      stopSound(id);
    }
  }
}

async function fadeOutAll(ms) {
  stopAll(ms);
}

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (!msg || msg.target !== 'offscreen') return;
  (async () => {
    if (msg.type === 'sync') await sync(msg.state);
    if (msg.type === 'set-master') setMasterVolume(msg.volume ?? 0.8, msg.ms || 120);
    if (msg.type === 'set-sound-volume') setVolume(msg.id, Math.max(0, Math.min(1, msg.volume ?? 0)), msg.ms || 120);
    if (msg.type === 'stop-all') stopAll(msg.ms ?? 0);
    if (msg.type === 'fade-out') await fadeOutAll(msg.ms || 5000);
    sendResponse?.({ ok: true });
  })();
  return true;
});

chrome.runtime.sendMessage({ target: 'background', type: 'get-state' }, (state) => {
  if (state) sync(state);
});
